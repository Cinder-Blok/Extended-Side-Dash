To exit, press ]
To use, PRESS e
-----------------
If you would like to change this, you can change it on line 9
e::
^
| change to whatever (Q MAY NOT WORK)
-----------------
Line 14 and 17 are what direction you go. (a for left and d for right) This can be changed to either d, a, or deleted. Deleted will result in YOU having to hold down either one. To delete you have to delete BOTH lines and line]] 13.

Send {d down} Send {d up}
      ^             ^
      |             | (A, D, or DELETE THE WHOLE LINE AND LINE 13)
-----------------

Solutions to Problems:

Not Pressing Emotes: Make sure you are using 2560 x 1440 and 100% scaling (If you can't, use other)
Not Opening Emotes: Use QWERTY keyboard layout

Anymore questions DM me on discord (.cinderblok) or email me (kaelpage@gmail.com)
